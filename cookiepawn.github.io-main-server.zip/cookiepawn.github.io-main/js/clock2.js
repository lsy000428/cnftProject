let handleId = 0;
const h4 = document.getElementById("day")

function getTime() {
    const date = new Date()
    let year = date.getFullYear()
    let month = ('0' + (date.getMonth() + 1)).slice(-2);
    let days = ('0' + date.getDate()).slice(-2);
    const hour = ('0' + date.getHours()).slice(-2); 
    const minutes = ('0' + date.getMinutes()).slice(-2);
    const seconds = ('0' + date.getSeconds()).slice(-2); 

    let hourP;
    let tmp;

    if(hour<=12){
        tmp = 'AM';
        hourP = hour;
    }
    else{
        tmp = 'PM';
        hourP = hour - 12;
    }

    if(hourP < 10) {
        hourP = '0' + hourP;
    }


    const day = `${year}.${month}.${days} ${hourP}:${minutes} ${tmp}`

    h4.textContent = day
}


handleId = setInterval(getTime, 100)