let adaID=0;
const price = document.getElementById("closing_price");
const rate = document.getElementById("fluctate_rate_24H");
const traded = document.getElementById("units_traded");
const options = {method: 'GET', headers: {accept: 'application/json'}};

function adaUpdate() {
    fetch('https://api.bithumb.com/public/ticker/ADA_KRW', options)
    .then(response => response.json())
    //.then(response => console.log(response))
    .then(data => {
      price.textContent = data.data.closing_price + 'KRW';
      traded.textContent = data.data.units_traded;


      if(((data.data.closing_price - data.data.prev_closing_price) / data.data.prev_closing_price * 100) >= 0) {
        rate.textContent = '+'+((data.data.closing_price - data.data.prev_closing_price) / data.data.prev_closing_price * 100).toFixed(2)+'%';
        rate.style.color = "red";
      }
      else {
        rate.textContent = '-'+((data.data.closing_price - data.data.prev_closing_price) / data.data.prev_closing_price * 100).toFixed(2)+'%';
        rate.style.color = "blue";
      }

      //console.log(data);
    })
    .catch(err => console.error(err));
}

adaID = setInterval(adaUpdate, 1000);
