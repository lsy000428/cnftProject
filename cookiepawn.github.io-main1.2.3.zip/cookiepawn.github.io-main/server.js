const express = require("express");
const url = require("url");
const multer  = require('multer');
const fs = require('fs');
var bodyParser = require('body-parser')
const upload = multer({ dest: 'postImg/' })
const urlencode = require("urlencode");
const server = express();
const mysql = require('mysql');  // mysql 모듈 로드

//DB연동
var db = mysql.createConnection({
  host : 'localhost',
  user : 'root',
  password : '1234',
  database : 'post',
  "timezone":"Asia/Seoul",
  "dateStrings":"date",
  multipleStatements: true
});
let sql;
let sql2;



db.connect();


server.use(bodyParser.urlencoded({limit: '5mb', extended: false, parameterLimit: 10000}));
server.use(express.urlencoded({extended: true}));
server.use(express.static(__dirname));
server.set('view engine', 'ejs');




server.get("/", (req, res) => {
  sql = `SELECT * FROM postInfo ORDER BY postNum DESC LIMIT 3; `;
  sql2 = `SELECT * FROM postInfo ORDER BY hit DESC LIMIT 4; `;
  db.query(sql + sql2, (error, data, fields) => {
    if(error) throw error;
    res.render(__dirname + "/ejs/main", {
      list1 : data[0],
      list2 : data[1]
    });
  });
});

server.get("/main", (req, res) => {
  sql = `SELECT * FROM postInfo ORDER BY postNum DESC LIMIT 3; `;
  sql2 = `SELECT * FROM postInfo ORDER BY hit DESC LIMIT 4; `;
  db.query(sql + sql2, (error, data, fields) => {
    if(error) throw error;
    res.render(__dirname + "/ejs/main_Login", {
      list1 : data[0],
      list2 : data[1]
    });
  });
});

server.get("/login", (req, res) => {
  res.sendFile(__dirname + "/loginPage.html");
});


server.get("/aidaNews", (req, res) => {
  var urlPath = url.parse(req.url);
  
  if(urlPath.path == '/aidaNews') {
    sql = `SELECT * FROM aidaNews`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
      res.render(__dirname + "/ejs/aidaNews", {
        list : data
      });
    });
  }
  else {
    var search = urlencode.decode(urlPath.query.replace(/postSearch=/, ""));
    sql = `SELECT * FROM aidaNews WHERE title LIKE '%${search}%'`;
    db.query(sql, (error, data, fields) => {
      if(error) throw error;
      res.render(__dirname + "/ejs/aidaNews", {
        list : data
      });
    });
  }
});

server.get("/newsPostPage", (req, res) => {
  res.sendFile(__dirname + "/newsPostPage.html");
});

server.post("/newsPostPage", upload.single("files"), (req, res) => {
  const title = req.body['postTitle'];
  const content = req.body['postContent'];
  const nickname = req.body['nickname'];
  const icon = req.body['icon'];
  const email = req.body['email'];
  const image = req.file;
  var btn = req.body['posting'];


  if(btn == '포스팅' && image == null) {
    sql = `INSERT INTO aidaNews (author, authorIcon, email, title, content, img, DATE, hit) VALUES('${nickname}', '${icon}', '${email}', '${title}', '${content}', '', now(), 1)`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });
    res.redirect("/aidaNews_Login");
  }
  else {
    sql = `INSERT INTO aidaNews (author, authorIcon, email, title, content, img, DATE, hit) VALUES('${nickname}', '${icon}', '${email}', '${title}', '${content}', '${image.filename}', now(), 1)`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });
    res.redirect("/aidaNews_Login");
  }
});


server.get("/aidaNews_Login", (req, res) => {
  var urlPath = url.parse(req.url);
  
  if(urlPath.path == '/aidaNews_Login') {
    sql = `SELECT * FROM aidaNews`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
      res.render(__dirname + "/ejs/aidaNews_Login", {
        list : data
      });
    });
  }
  else {
    var search = urlencode.decode(urlPath.query.replace(/postSearch=/, ""));

    sql = `SELECT * FROM aidaNews WHERE title LIKE '%${search}%'`;
    db.query(sql, (error, data, fields) => {
      if(error) throw error;
      res.render(__dirname + "/ejs/aidaNews_Login", {
        list : data
      });
    });
  }
});

server.get("/aidaNewsInfo", (req, res) => {
  var urlPath = url.parse(req.url);
  var search = urlencode.decode(urlPath.query.replace(/postID=/, ""));

  sql = `UPDATE aidanews SET hit = hit + 1 WHERE postNum = ${search};`;
  sql2 = `SELECT * FROM aidanews WHERE postNum LIKE '%${search}%';`;
  db.query(sql + sql2, (error, data, fields) => {
    if(error) throw error;
    res.render(__dirname + "/ejs/aidaNewsInfo", {
      list : data[1]
    });
  });
});

server.get("/aidaNewsInfo_Login", (req, res) => {
  var urlPath = url.parse(req.url);
  var search = urlencode.decode(urlPath.query.replace(/postID=/, ""));

  sql = `UPDATE aidanews SET hit = hit + 1 WHERE postNum = ${search};`;
  sql2 = `SELECT * FROM aidanews WHERE postNum LIKE '%${search}%';`;
  db.query(sql + sql2, (error, data, fields) => {
    if(error) throw error;
    res.render(__dirname + "/ejs/aidaNewsInfo_Login", {
      list : data[1]
    });
  });
});

server.get("/aidaNewsUpdate", (req, res) => {
  var urlPath = url.parse(req.url);
  var search = urlencode.decode(urlPath.query.replace(/postID=/, ""));

  sql = `SELECT * FROM aidanews WHERE postNum LIKE '%${search}%'`;
  db.query(sql, (error, data, fields) => {
    if(error) throw error;
    res.render(__dirname + "/ejs/aidaNewsUpdate", {
      list : data
    });
  });
});



server.post("/aidaNewsInfo_Login", (req, res) => {
  var urlPath = url.parse(req.url);
  var search = urlencode.decode(urlPath.query.replace(/postID=/, ""));


  var btnName = req.body['delete'];
  if (btnName == '삭제') {
    sql = `SELECT * FROM aidanews WHERE postNum = ${search};`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
      if(data[0].img != '') {
        try {
            fs.unlinkSync(`postImg/${data[0].img}`);
        } catch (error) {
            if(err.code == 'ENOENT'){
                console.log("파일 삭제 Error 발생");
            }
        }
      }
    });

    sql = `DELETE FROM aidanews WHERE postNum = ${search};`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });
    res.redirect("/aidaNews_Login");
  }
});









server.get("/cnftPost", (req, res) => {
  var urlPath = url.parse(req.url);
  
  if(urlPath.path == '/cnftPost') {
    sql = `SELECT * FROM postInfo`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
      res.render(__dirname + "/ejs/cnftPostPage", {
        list : data
      });
    });
  }
  else {
    var search = urlencode.decode(urlPath.query.replace(/postSearch=/, ""));
    sql = `SELECT * FROM postInfo WHERE title LIKE '%${search}%'`;
    db.query(sql, (error, data, fields) => {
      if(error) throw error;
      res.render(__dirname + "/ejs/cnftPostPage", {
        list : data
      });
    });
  }
});

server.get("/cnftPost_Login", (req, res) => {
  var urlPath = url.parse(req.url);
  
  if(urlPath.path == '/cnftPost_Login') {
    sql = `SELECT * FROM postInfo`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
      res.render(__dirname + "/ejs/cnftPostPage_Login", {
        list : data
      });
    });
  }
  else {
    var search = urlencode.decode(urlPath.query.replace(/postSearch=/, ""));

    sql = `SELECT * FROM postInfo WHERE title LIKE '%${search}%'`;
    db.query(sql, (error, data, fields) => {
      if(error) throw error;
      res.render(__dirname + "/ejs/cnftPostPage_Login", {
        list : data
      });
    });
  }
});

server.get("/cnftPostInfo", (req, res) => {
  var urlPath = url.parse(req.url);
  var search = urlencode.decode(urlPath.query.replace(/postID=/, ""));

  sql = `UPDATE postInfo SET hit = hit + 1 WHERE postNum = ${search};`;
  sql2 = `SELECT * FROM postInfo WHERE postNum LIKE '%${search}%';`;
  db.query(sql + sql2, (error, data, fields) => {
    if(error) throw error;
    res.render(__dirname + "/ejs/cnftPostInfo", {
      list : data[1]
    });
  });
});

server.get("/cnftPostInfo_Login", (req, res) => {
  var urlPath = url.parse(req.url);
  var search = urlencode.decode(urlPath.query.replace(/postID=/, ""));

  sql = `UPDATE postInfo SET hit = hit + 1 WHERE postNum = ${search};`;
  sql2 = `SELECT * FROM postInfo WHERE postNum LIKE '%${search}%';`;
  db.query(sql + sql2, (error, data, fields) => {
    if(error) throw error;
    res.render(__dirname + "/ejs/cnftPostInfo_Login", {
      list : data[1]
    });
  });
});

server.get("/cnftPosting", (req, res) => {
  res.sendFile(__dirname + "/cnftPostingPage.html");
});

server.get("/cnftPostUpdate", (req, res) => {
  var urlPath = url.parse(req.url);
  var search = urlencode.decode(urlPath.query.replace(/postID=/, ""));

  sql = `SELECT * FROM postInfo WHERE postNum LIKE '%${search}%'`;
  db.query(sql, (error, data, fields) => {
    if(error) throw error;
    res.render(__dirname + "/ejs/cnftPostUpdate", {
      list : data
    });
  });
});

server.get("/enterInfo", (req, res) => {
  res.sendFile(__dirname + "/enterInfoPage.html");
});





server.listen(3000, (err) => {
  if (err) return console.log(err);
  console.log("The server is listening on port 3000");
});





server.post("/", (req, res) => {
  const id = req.body['postID'];

  sql = `UPDATE postInfo SET hit = hit + 1 WHERE postNum = ${id}`;
  db.query(sql, (error, data, fields) => {
    if(error) throw error;
  });
  res.redirect("/cnftPostInfo");
});


server.post("/main", (req, res) => {
  const id = req.body['postID'];

  sql = `UPDATE postInfo SET hit = hit + 1 WHERE postNum = ${id}`;
  db.query(sql, (error, data, fields) => {
    if(error) throw error;
  });
  res.redirect("/cnftPostInfo_Login");
});



server.post("/cnftPosting", upload.single("files"), (req, res) => {
  const title = req.body['postTitle'];
  const content = req.body['postContent'];
  const nickname = req.body['nickname'];
  const icon = req.body['icon'];
  const email = req.body['email'];
  const image = req.file;
  var btn = req.body['posting'];


  if(btn == '포스팅' && image == null) {
    sql = `INSERT INTO postInfo (author, authorIcon, email, title, content, img, DATE, hit) VALUES('${nickname}', '${icon}', '${email}', '${title}', '${content}', '', now(), 1)`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });
    res.redirect("/cnftPost_Login");
  }
  else {
    sql = `INSERT INTO postInfo (author, authorIcon, email, title, content, img, DATE, hit) VALUES('${nickname}', '${icon}', '${email}', '${title}', '${content}', '${image.filename}', now(), 1)`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });
    res.redirect("/cnftPost_Login");
  }
});


server.post("/cnftPostInfo_Login", (req, res) => {
  var urlPath = url.parse(req.url);
  var search = urlencode.decode(urlPath.query.replace(/postID=/, ""));


  var btnName = req.body['delete'];
  if (btnName == '삭제') {
    sql = `SELECT * FROM postInfo WHERE postNum = ${search};`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
      if(data[0].img != '') {
        try {
            fs.unlinkSync(`postImg/${data[0].img}`);
        } catch (error) {
            if(err.code == 'ENOENT'){
                console.log("파일 삭제 Error 발생");
            }
        }
      }
    });

    sql = `DELETE FROM postInfo WHERE postNum = ${search};`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });
    res.redirect("/cnftPost_Login");
  }
});