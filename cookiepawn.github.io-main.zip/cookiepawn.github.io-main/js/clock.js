let handleId = 0;
const h3 = document.getElementById("day")
const h4 = document.getElementById("time")

function getTime() {
    const date = new Date()
    let year = date.getFullYear()
    let month = date.getMonth() + 1
    let days = date.getDate()
    const hour = date.getHours()
    const minutes = date.getMinutes()
    const seconds = date.getSeconds()

    const day = `${year}년 ${month}월 ${days}일`
    const time = `${hour}시 ${minutes}분 ${seconds}초`
    h3.textContent = day
    h4.textContent = time
}


handleId = setInterval(getTime, 100)