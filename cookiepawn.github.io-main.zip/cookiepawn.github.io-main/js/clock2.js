let handleId = 0;
const h4 = document.getElementById("day")

function getTime() {
    const date = new Date()
    let year = date.getFullYear()
    let month = date.getMonth() + 1
    let days = date.getDate()
    const hour = date.getHours()
    const minutes = date.getMinutes()
    const seconds = date.getSeconds()

    let hourP;
    let tmp;

    if(hour<=12){
        tmp = 'AM';
        hourP = hour;
    }
    else{
        tmp = 'PM';
        hourP = hour - 12;
    }


    const day = `${year}.${month}.${days} ${hourP}:${minutes} ${tmp}`

    h4.textContent = day
}


handleId = setInterval(getTime, 100)