var c = document.getElementById("color"),
    ta = document.getElementById("textArea"),
    tmp;

    c.addEventListener("input", function() {
        tmp = c.value;
        ta.style.color = tmp;
    }, false); 


