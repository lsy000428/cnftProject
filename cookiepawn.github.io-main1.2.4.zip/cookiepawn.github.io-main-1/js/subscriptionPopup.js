const openBtn = document.querySelector(".subscriptionPaymentsOpenBtn");
const closeBtn = document.querySelector(".subscriptionPaymentsCloseBtn");
const div = document.getElementById("subscriptionPaymentsDiv");
const dimmed2 = document.getElementById("dimmedID");

openBtn.addEventListener("click", e=> {
    div.style.display = "flex";
    dimmed2.style.display = "flex";
});

closeBtn.addEventListener("click", e=> {
    div.style.display = "none";
    dimmed2.style.display = "none";
});

function openPaymentsPopup(){
    div.style.display = "flex";
    dimmed2.style.display = "flex";
}