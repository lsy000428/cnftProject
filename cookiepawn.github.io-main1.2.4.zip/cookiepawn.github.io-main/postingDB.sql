DROP DATABASE post;
CREATE DATABASE post;
USE post;


CREATE TABLE postInfo(
	postNum			INTEGER PRIMARY KEY auto_increment,
    author			VARCHAR(20),
    authorIcon		text,
    email			text,
    title			text,
    content			LONGTEXT,
    img				text,
    DATE			DATE,
    hit				INTEGER
);

CREATE TABLE aidaNews(
	postNum			INTEGER PRIMARY KEY auto_increment,
    author			VARCHAR(20),
    authorIcon		text,
    email			text,
    title			text,
    content			LONGTEXT,
    img				text,
    DATE			DATE,
    hit				INTEGER
);
SELECT * FROM post.aidaNews;
SELECT * FROM post.postInfo;


set SQL_SAFE_UPDATES = 0;


AlTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '1234';
FLUSH privileges;
