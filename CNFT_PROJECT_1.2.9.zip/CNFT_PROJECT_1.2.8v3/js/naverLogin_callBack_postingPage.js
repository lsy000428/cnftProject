var naverLogin = new naver.LoginWithNaverId(
   {
      clientId: "fF_n9MMtYWJjeyNVzYDQ", //내 애플리케이션 정보에 cliendId를 입력해줍니다.
      callbackUrl: "http://localhost:3000/main", // 내 애플리케이션 API설정의 Callback URL 을 입력해줍니다.
      isPopup: false,
      callbackHandle: true
   }
);  


naverLogin.init();


window.addEventListener('load', function () {
   naverLogin.getLoginStatus(function (status) {
      if (status) {
         var email = naverLogin.user.getEmail(); // 필수로 설정할것을 받아와 아래처럼 조건문을 줍니다.
         const age = naverLogin.user.getAge();
         const birthday = naverLogin.user.getBirthday();
         const birthyear = naverLogin.user.getBirthyear();
         const gender = naverLogin.user.getGender();            
         const id = naverLogin.user.getId();
         const mobile = naverLogin.user.getMobile();
         const name = naverLogin.user.getName();
         const nickname = naverLogin.user.getNickName();
         const profile_img = naverLogin.user.getProfileImage();

         let target = document.getElementById("userNickName");

         let observer = new MutationObserver((mutations) => {
            document.getElementById("nicknameID").setAttribute("value", nickname);
            document.getElementById("iconID").setAttribute("value", profile_img);
            document.getElementById("emailID").setAttribute("value", email);
            document.getElementById("ageID").setAttribute("value", age);
            document.getElementById("phoneID").setAttribute("value", mobile);
         })
         let option = {
             attributes: true,
             childList: true,
             characterData: true
         };
         observer.observe(target, option);

         
         document.getElementById("userNickName").textContent = nickname;
         document.getElementById("login_userInfoBtn").setAttribute("onClick", "location.href='/main'");
         document.getElementById("login_userInfoImg").setAttribute("src", profile_img);
         document.getElementById("login_userInfoImg").setAttribute("alt", "회원정보");
         document.getElementById("login_userInfoImg").setAttribute("title", "회원정보");


         if( email == undefined || email == null) {
            alert("이메일은 필수정보입니다. 정보제공을 동의해주세요.");
            naverLogin.reprompt();
            return;
         }
      } else {
         console.log("callback 처리에 실패하였습니다.");
      }
   });
});




var testPopUp;
function openPopUp() {
   testPopUp= window.open("https://nid.naver.com/nidlogin.logout", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=1,height=1");
}
function closePopUp(){
   testPopUp.close();
   location.href = "/";
}

function naverLogout() {
   openPopUp();

   setTimeout(function() {
      closePopUp();
   }, 500);

   nicknameVal = "";
   document.getElementById("userNickName").textContent = "";
   document.getElementById("login_userInfoBtn").setAttribute("onClick", "location.href='loginPage.html'");
   document.getElementById("login_userInfoImg").setAttribute("src", "img/login.png");
   document.getElementById("login_userInfoImg").setAttribute("alt", "로그인")
   document.getElementById("login_userInfoImg").setAttribute("title", "로그인");

   sessionStorage.clear();
   console.clear();

}