const multer = require('multer');
const upload = multer({dest : 'postImg/' })
const express = require("express");
const server = express();
const mysql = require('mysql');  // mysql 모듈 로드


//DB연동
var db = mysql.createConnection({
  host : 'localhost',
  user : 'root',
  password : '1234',
  database : 'post',
  "timezone":"Asia/Seoul",
  "dateStrings":"date"
});
let sql;




db.connect();



server.use(express.urlencoded({extended: true}));
server.use(express.static(__dirname));
server.set('view engine', 'ejs');



server.get("/", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

server.get("/login", (req, res) => {
  res.sendFile(__dirname + "/loginPage.html");
});

server.get("/blog", (req, res) => {
  res.sendFile(__dirname + "/blogPage.html");
});

server.get("/main", (req, res) => {
  res.sendFile(__dirname + "/mainPage.html");
});

server.get("/cnftPost", (req, res) => {

  sql = `SELECT * FROM postInfo`;

  db.query(sql, (error, data, fields) =>{
    if(error) throw error;

    res.render(__dirname + "/ejs/cnftPostPage", {
      list : data
    });
  });
});

server.get("/cnftPostInfo", (req, res) => {

  sql = `SELECT * FROM postInfo WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`

  db.query(sql, (error, data, fields) => {
    if(error) throw error;

    res.render(__dirname + "/ejs/cnftPostInfo", {
      list : data
    });
  });
});

server.get("/cnftPosting", (req, res) => {
  res.sendFile(__dirname + "/cnftPostingPage.html");
});

server.get("/cnftPostUpdate", (req, res) => {
  sql = `SELECT * FROM postInfo WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`

  db.query(sql, (error, data, fields) => {
    if(error) throw error;

    res.render(__dirname + "/ejs/cnftPostUpdate", {
      list : data
    });
  });
});

server.get("/enterInfo", (req, res) => {
  res.sendFile(__dirname + "/enterInfoPage.html");
});

server.get("/blogPost", (req, res) => {
  res.sendFile(__dirname + "/postingPage.html");
});

server.get("/read/:idx", (req, res, next)=>{
  const idx = req.params.idx;
  const sql = 
    "SELECT postNum, author_id, title, content, image, date, hit FROM postinfo WHERE postNum=?";
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
        else{res.render("read", {title : "글조회",row:row[0]});
      }
    });
})




server.listen(3000, (err) => {
  if (err) return console.log(err);
  console.log("The server is listening on port 3000");
});




server.post("/cnftPosting",upload.single('postImage'), (req, res) => {
  const title = req.body['postTitle'];
  const content = req.body['postContent'];
  const image = `/postimg/${req.file.filename}`;

  var btn = req.body['posting'];

  if(btn == '포스팅') {
    sql = `INSERT INTO postInfo (author_id, title, content, img, DATE, hit) VALUES(1, '${title}', '${content}', '${image}', now(), 1)`;

    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });

    res.redirect("/cnftPost");
  }
  
  btn = req.body['back'];
  if(btn == '취소') {
    res.redirect("/cnftPost");
  }
});

server.post("/cnftPost", (req, res) => {
  const id = req.body['postID'];

  sql = `INSERT INTO hitCnt (postNum) VALUE(${id})`
  db.query(sql, (error, data, fields) => {
    if(error) throw error;
  });

  res.redirect("/cnftPostInfo");
});

server.post("/cnftPostInfo", (req, res) => {
  var btnName = req.body['update'];
  if(btnName == '수정'){
    res.redirect("/cnftPostUpdate");
  }

  btnName = req.body['delete'];
  if (btnName == '삭제') {
    sql = `DELETE FROM postInfo WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });
    res.redirect("/cnftPost");
  }

  btnName = req.body['back'];
  if (btnName == '뒤로가기') {
    res.redirect("/cnftPost");
  }
});

server.post("/cnftPostUpdate", (req, res) => {
  var btnName = req.body['update'];
  if(btnName == '수정'){
    var title = req.body['postTitle'];
    var content = req.body['postContent'];

    sql = `UPDATE postInfo SET title = '${title}' WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) => {
      if(error) throw error;
    });

    sql = `UPDATE postInfo SET content = '${content}' WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) => {
      if(error) throw error;
    });

    res.redirect("/cnftPostInfo");
  }

  btnName = req.body['back'];
  if (btnName == '뒤로가기') {
    res.redirect("/cnftPostInfo");
  }
});