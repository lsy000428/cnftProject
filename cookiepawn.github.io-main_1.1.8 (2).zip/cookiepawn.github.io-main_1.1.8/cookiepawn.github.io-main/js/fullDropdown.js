const ul1 = document.querySelector(".li.c1 > ul");
const ul1s1 = document.querySelector(".li.c1 > .li.sub1");
const ul2 = document.querySelector(".li.c2 > ul");
const ul2s1 = document.querySelector(".li.c2 > .li.sub1");
const ul2s2 = document.querySelector(".li.c2 > .li.sub2");
const ul2s3 = document.querySelector(".li.c2 > .li.sub3");
const ul3 = document.querySelector(".li.c3 > ul");
const ul4 = document.querySelector(".li.c4 > ul");
const ul5 = document.querySelector(".li.c5 > ul");
const ul5s1 = document.querySelector(".li.c5 > .li.sub1");
const ul6 = document.querySelector(".li.c6 > ul");
const li1 = document.querySelector(".li.c1");
const li2 = document.querySelector(".li.c2");
const li3 = document.querySelector(".li.c3");
const li4 = document.querySelector(".li.c4");
const li5 = document.querySelector(".li.c5");
const li6 = document.querySelector(".li.c6");

const header = document.querySelector(".header.mainHeader");
const dropdown = document.querySelector(".dropdown");
const dimmed = document.getElementById("dimmedID");



dropdown.addEventListener('mouseenter', e=> {
    header.style.height = "400px";
    dropdown.style.height = "400px";
    dimmed.style.display = "flex";
});

li1.addEventListener('mouseenter', e=> {
    ul1.style.display = "block";
    ul1s1.style.display = "block";
    ul2.style.display = "none";
    ul2s1.style.display = "none";
    ul2s2.style.display = "none";
    ul2s3.style.display = "none";
    ul3.style.display = "none";
    ul4.style.display = "none";
    ul5.style.display = "none";
    ul5s1.style.display = "none";
    ul6.style.display = "none";
});
li2.addEventListener('mouseenter', e=> {
    ul2.style.display = "block";
    ul2s1.style.display = "block";
    ul2s2.style.display = "block";
    ul2s3.style.display = "block";
    ul1.style.display = "none";
    ul1s1.style.display = "none";
    ul3.style.display = "none";
    ul4.style.display = "none";
    ul5.style.display = "none";
    ul5s1.style.display = "none";
    ul6.style.display = "none";
});
li3.addEventListener('mouseenter', e=> {
    ul3.style.display = "block";
    ul1.style.display = "none";
    ul1s1.style.display = "none";
    ul2.style.display = "none";
    ul2s1.style.display = "none";
    ul2s2.style.display = "none";
    ul2s3.style.display = "none";
    ul4.style.display = "none";
    ul5.style.display = "none";
    ul5s1.style.display = "none";
    ul6.style.display = "none";
});
li4.addEventListener('mouseenter', e=> {
    ul4.style.display = "block";
    ul1.style.display = "none";
    ul1s1.style.display = "none";
    ul2.style.display = "none";
    ul2s1.style.display = "none";
    ul2s2.style.display = "none";
    ul2s3.style.display = "none";
    ul3.style.display = "none";
    ul5.style.display = "none";
    ul5s1.style.display = "none";
    ul6.style.display = "none";
});
li5.addEventListener('mouseenter', e=> {
    ul5.style.display = "block";
    ul5s1.style.display = "block";
    ul1.style.display = "none";
    ul1s1.style.display = "none";
    ul2.style.display = "none";
    ul2s1.style.display = "none";
    ul2s2.style.display = "none";
    ul2s3.style.display = "none";
    ul3.style.display = "none";
    ul4.style.display = "none";
    ul6.style.display = "none";
});
li6.addEventListener('mouseenter', e=> {
    ul6.style.display = "block";
    ul1.style.display = "none";
    ul1s1.style.display = "none";
    ul2.style.display = "none";
    ul2s1.style.display = "none";
    ul2s2.style.display = "none";
    ul2s3.style.display = "none";
    ul3.style.display = "none";
    ul4.style.display = "none";
    ul5.style.display = "none";
    ul5s1.style.display = "none";
});



header.addEventListener('mouseleave', e=> {
    ul1.style.display = "none";
    ul1s1.style.display = "none";
    ul2.style.display = "none";
    ul2s1.style.display = "none";
    ul2s2.style.display = "none";
    ul2s3.style.display = "none";
    ul3.style.display = "none";
    ul4.style.display = "none";
    ul5.style.display = "none";
    ul5s1.style.display = "none";
    ul6.style.display = "none";
    header.style.height = "100px";
    dropdown.style.height = "100px";
    dimmed.style.display = "none";
});