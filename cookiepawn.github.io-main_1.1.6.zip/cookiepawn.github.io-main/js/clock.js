let handleId = 0;
const h3 = document.getElementById("day")
const h4 = document.getElementById("time")

function getTime() {
    const date = new Date()
    let year = date.getFullYear()
    let month = ('0' + (date.getMonth() + 1)).slice(-2);
    let days = ('0' + date.getDate()).slice(-2);
    const hour = ('0' + date.getHours()).slice(-2); 
    const minutes = ('0' + date.getMinutes()).slice(-2);
    const seconds = ('0' + date.getSeconds()).slice(-2); 

    const day = `${year}년 ${month}월 ${days}일`
    const time = `${hour}시 ${minutes}분 ${seconds}초`
    h3.textContent = day
    h4.textContent = time
}


handleId = setInterval(getTime, 100)