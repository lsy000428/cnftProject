const express = require("express");
const server = express();
const mysql = require('mysql');  // mysql 모듈 로드

//DB연동
var db = mysql.createConnection({
  host : 'localhost',
  user : 'root',
  password : 'Dks135790@',
  database : 'post'
});
let sql;




db.connect();



server.use(express.urlencoded({extended: true}));
server.use(express.static(__dirname));
server.set('view engine', 'ejs');



server.get("/", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

server.get("/login", (req, res) => {
  res.sendFile(__dirname + "/loginPage.html");
});

server.get("/blog", (req, res) => {
  res.sendFile(__dirname + "/blogPage.html");
});

server.get("/main", (req, res) => {
  res.sendFile(__dirname + "/mainPage.html");
});

server.get("/cnftPost", (req, res) => {

  sql = `SELECT * FROM postInfo`;

  db.query(sql, (error, data, fields) =>{
    if(error) throw error;

      res.render(__dirname + "/ejs/cnftPostPage", {
        list : JSON.stringify(data)
      });
  });
});

server.get("/cnftPostInfo", (req, res) => {

  sql = `SELECT * FROM postInfo WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`

  db.query(sql, (error, data, fields) => {
    if(error) throw error;

    res.render(__dirname + "/ejs/cnftPostInfo", {
      list : JSON.stringify(data)
    });
  });
});

server.get("/cnftPosting", (req, res) => {
  res.sendFile(__dirname + "/cnftPostingPage.html");
});

server.get("/enterInfo", (req, res) => {
  res.sendFile(__dirname + "/enterInfoPage.html");
});

server.get("/blogPost", (req, res) => {
  res.sendFile(__dirname + "/postingPage.html");
});

server.listen(3000, (err) => {
  if (err) return console.log(err);
  console.log("The server is listening on port 3000");
});

server.post("/cnftPosting", (req, res) => {
  const title = req.body['postTitle'];
  const content = req.body['postContent'];
  const image = req.body['postImage'];

  sql = `INSERT INTO postInfo (author_id, title, content, img, DATE, hit) VALUES(1, '${title}', '${content}', '${image}', now(), 1)`;

  db.query(sql, (error, data, fields) =>{
    if(error) throw error;
  });

  res.redirect("/cnftPost");
});

server.post("/cnftPost", (req, res) => {
  const id = req.body['postID'];

  sql = `INSERT INTO hitCnt (postNum) VALUE(${id})`
  db.query(sql, (error, data, fields) => {
    if(error) throw error;
  });

  res.redirect("/cnftPostInfo");
});

server.post("/cnftPostInfo", (req, res) => {
  res.redirect("/cnftPost");
});