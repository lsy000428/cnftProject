let day;


var IMP = window.IMP; 
IMP.init('imp35844342'); 

function tossPay() {
    getTime();

    IMP.request_pay({
        pg : 'tosspay.tosstest',
        pay_method : 'card',
        merchant_uid: `${day}`, 
        name : '당근 10kg',
        amount : 1999999,
        buyer_email : 'Iamport@chai.finance',
        buyer_name : '아임포트 기술지원팀',
        buyer_tel : '010-1234-5678',
        buyer_addr : '서울특별시 강남구 삼성동',
        buyer_postcode : '123-456'
    }, function (rsp) { // callback
        if (rsp.success) {
            console.log(rsp);
        } else { 
            console.log(rsp);
        }
    });
}

function kakaoPay() {
    getTime();

    IMP.request_pay({
        pg : 'kakaopay.TC0ONETIME',
        pay_method : 'card',
        merchant_uid: `${day}`, 
        name : '강남 힐스테이트',
        amount : 100000000,
        buyer_email : 'Iamport@chai.finance',
        buyer_name : '아임포트 기술지원팀',
        buyer_tel : '010-1234-5678',
        buyer_addr : '서울특별시 강남구 삼성동',
        buyer_postcode : '123-456'
    }, function (rsp) { // callback
        if (rsp.success) {
            console.log(rsp);
        } else { 
            console.log(rsp);
        }
    });
}



function getTime() {
    const date = new Date()
    let year = date.getFullYear()
    let month = ('0' + (date.getMonth() + 1)).slice(-2);
    let days = ('0' + date.getDate()).slice(-2);
    const hour = ('0' + date.getHours()).slice(-2); 
    const minutes = ('0' + date.getMinutes()).slice(-2);
    const seconds = ('0' + date.getSeconds()).slice(-2); 

    day = `${year}${month}${days}-${hour}${minutes}${seconds}`
}
