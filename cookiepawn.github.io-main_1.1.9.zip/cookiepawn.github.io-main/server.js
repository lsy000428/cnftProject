const express = require("express");
const url = require("url");
const multer  = require('multer');
const fs = require('fs');
const upload = multer({ dest: 'postImg/' })
const urlencode = require("urlencode");
const server = express();
const mysql = require('mysql');  // mysql 모듈 로드

//DB연동
var db = mysql.createConnection({
  host : 'localhost',
  user : 'root',
  password : 'Dks135790@',
  database : 'post',
  "timezone":"Asia/Seoul",
  "dateStrings":"date"
});
let sql;




db.connect();



server.use(express.urlencoded({extended: true}));
server.use(express.static(__dirname));
server.set('view engine', 'ejs');



server.get("/", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

server.get("/login", (req, res) => {
  res.sendFile(__dirname + "/loginPage.html");
});

server.get("/blog", (req, res) => {
  res.sendFile(__dirname + "/blogPage.html");
});

server.get("/main", (req, res) => {
  res.sendFile(__dirname + "/mainPage.html");
});

server.get("/cnftPost", (req, res) => {
  var urlPath = url.parse(req.url);
  

  if(urlPath.path == '/cnftPost') {
    sql = `SELECT * FROM postInfo`;

    db.query(sql, (error, data, fields) =>{
      if(error) throw error;

      res.render(__dirname + "/ejs/cnftPostPage", {
        list : data
      });
    });
  }
  else {
    var search = urlencode.decode(urlPath.query.replace(/postSearch=/, ""));
    sql = `SELECT * FROM postInfo WHERE title LIKE '%${search}%'`;

    db.query(sql, (error, data, fields) => {
      if(error) throw error;

      res.render(__dirname + "/ejs/cnftPostPage", {
        list : data
      });
    });
  }
  
});

server.get("/cnftPostInfo", (req, res) => {

  sql = `SELECT * FROM postInfo WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`

  db.query(sql, (error, data, fields) => {
    if(error) throw error;

    res.render(__dirname + "/ejs/cnftPostInfo", {
      list : data
    });
  });
});

server.get("/cnftPosting", (req, res) => {
  res.sendFile(__dirname + "/cnftPostingPage.html");
});

server.get("/cnftPostUpdate", (req, res) => {
  sql = `SELECT * FROM postInfo WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`

  db.query(sql, (error, data, fields) => {
    if(error) throw error;

    res.render(__dirname + "/ejs/cnftPostUpdate", {
      list : data
    });
  });
});

server.get("/enterInfo", (req, res) => {
  res.sendFile(__dirname + "/enterInfoPage.html");
});

server.get("/blogPost", (req, res) => {
  res.sendFile(__dirname + "/postingPage.html");
});




server.listen(3000, (err) => {
  if (err) return console.log(err);
  console.log("The server is listening on port 3000");
});




server.post("/cnftPosting", upload.single('postImage'), (req, res) => {
  const title = req.body['postTitle'];
  const content = req.body['postContent'];
  const image = req.file;
  var btn = req.body['posting'];


  if(btn == '포스팅' && image == null) {
    sql = `INSERT INTO postInfo (author_id, title, content, img, DATE, hit) VALUES(1, '${title}', '${content}', '', now(), 1)`;

    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });

    res.redirect("/cnftPost");
  }
  else {
    sql = `INSERT INTO postInfo (author_id, title, content, img, DATE, hit) VALUES(1, '${title}', '${content}', '${image.filename}', now(), 1)`;

    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });

    res.redirect("/cnftPost");
  }
  
  btn = req.body['back'];
  if(btn == '취소') {
    res.redirect("/cnftPost");
  }
});

server.post("/cnftPost", (req, res) => {
  const id = req.body['postID'];

  sql = `INSERT INTO hitCnt (postNum) VALUE(${id})`
  db.query(sql, (error, data, fields) => {
    if(error) throw error;
  });

  res.redirect("/cnftPostInfo");
});

server.post("/cnftPostInfo", (req, res) => {
  var btnName = req.body['update'];
  if(btnName == '수정'){
    res.redirect("/cnftPostUpdate");
  }

  btnName = req.body['delete'];
  if (btnName == '삭제') {
    sql = `SELECT * FROM postInfo WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;

      if(data[0].img != '') {
        try {
            fs.unlinkSync(`postImg/${data[0].img}`);
        } catch (error) {
            if(err.code == 'ENOENT'){
                console.log("파일 삭제 Error 발생");
            }
        }
      }
    });

    sql = `DELETE FROM postInfo WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) =>{
      if(error) throw error;
    });
    res.redirect("/cnftPost");
  }

  btnName = req.body['back'];
  if (btnName == '뒤로가기') {
    res.redirect("/cnftPost");
  }
});

server.post("/cnftPostUpdate", upload.single('postImg'), (req, res) => {
  var btnName = req.body['update'];
  var image = req.file;
  
  if (btnName == '수정' && image == null){
    var title = req.body['postTitle'];
    var content = req.body['postContent'];

    sql = `UPDATE postInfo SET title = '${title}' WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) => {
      if(error) throw error;
    });

    sql = `UPDATE postInfo SET content = '${content}' WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) => {
      if(error) throw error;
    });

    res.redirect("/cnftPostInfo");
  }
  else if (btnName == '수정' && image != null){
    var title = req.body['postTitle'];
    var content = req.body['postContent'];

    sql = `SELECT * FROM postInfo WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;
    db.query(sql, (error, data, fields) =>{
      if(error) throw error;

      if(data[0].img != '') {
        try {
            fs.unlinkSync(`postImg/${data[0].img}`);
        } catch (error) {
            if(err.code == 'ENOENT'){
                console.log("파일 삭제 Error 발생");
            }
        }
      }
    });

    sql = `UPDATE postInfo SET title = '${title}' WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) => {
      if(error) throw error;
    });

    sql = `UPDATE postInfo SET content = '${content}' WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) => {
      if(error) throw error;
    });

    sql = `UPDATE postInfo SET img = '${image.filename}' WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) => {
      if(error) throw error;
    });

    res.redirect("/cnftPostInfo");
  }

  btnName = req.body['back'];
  if (btnName == '뒤로가기') {
    res.redirect("/cnftPostInfo");
  }

  btnName = req.body['imgDelete'];
  if(btnName == '이미지 지우기'){

    sql = `UPDATE postInfo SET img = '' WHERE postNum = (SELECT postNum FROM hitCnt ORDER BY hitNum DESC LIMIT 1);`;

    db.query(sql, (error, data, fields) => {
      if(error) throw error;
    });
    res.redirect("/cnftPostUpdate");
  }
});