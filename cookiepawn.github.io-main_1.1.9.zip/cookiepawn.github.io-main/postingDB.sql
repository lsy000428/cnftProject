DROP DATABASE post;
CREATE DATABASE post;
USE post;


CREATE TABLE postInfo(
	postNum			INTEGER PRIMARY KEY auto_increment,
    author_id		VARCHAR(20),
    title			text,
    content			LONGTEXT,
    img				text,
    DATE			DATE,
    hit				INTEGER
);

CREATE TABLE hitCnt(
	hitNum			INTEGER PRIMARY KEY auto_increment,
	postNum			INTEGER
);

SELECT * FROM post.postInfo;
SELECT * FROM post.hitCnt;



AlTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Dks135790@';
FLUSH privileges;
